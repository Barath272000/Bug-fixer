import { apiRequest } from './client';
import type { Bug, SeverityLevel, BugStatus, AIStatus } from '../types';

/**
 * The backend's BugStatus enum has no spaces (Prisma enum values can't contain
 * spaces): Open | InReview | Fixed | Closed | AISuggested | ApplyingFix
 * The frontend's BugStatus type uses spaces for display: 'In Review', 'AI Suggested', etc.
 * These two maps convert between them at the API boundary so the rest of the
 * app never has to think about it.
 */
const STATUS_FROM_API: Record<string, BugStatus> = {
  Open: 'Open',
  InReview: 'In Review',
  Fixed: 'Fixed',
  Closed: 'Closed',
  AISuggested: 'AI Suggested',
  ApplyingFix: 'Applying Fix',
};

const STATUS_TO_API: Record<BugStatus, string> = {
  Open: 'Open',
  'In Review': 'InReview',
  Fixed: 'Fixed',
  Closed: 'Closed',
  'AI Suggested': 'AISuggested',
  'Applying Fix': 'ApplyingFix',
};

// Backend shape returned by GET /bugs, GET /bugs/:id, POST /bugs, PATCH /bugs/:id
interface ApiBug {
  id: string;
  projectId: string;
  code: string;
  title: string;
  description?: string | null;
  tags: string[];
  severity: SeverityLevel;
  status: string; // one of STATUS_FROM_API's keys
  aiStatus: AIStatus;
  language: string;
  component: string;
  filePath?: string | null;
  lineNumber?: number | null;
  stackTrace?: string | null;
  loggedDate: string;
  updatedAt: string;
}

function mapBugFromApi(apiBug: ApiBug): Bug {
  return {
    id: apiBug.id,
    code: apiBug.code,
    title: apiBug.title,
    tags: apiBug.tags,
    severity: apiBug.severity,
    status: STATUS_FROM_API[apiBug.status] ?? 'Open',
    aiStatus: apiBug.aiStatus,
    language: apiBug.language,
    component: apiBug.component,
    loggedDate: apiBug.loggedDate,
    updatedDate: apiBug.updatedAt,
    description: apiBug.description ?? undefined,
    stackTrace: apiBug.stackTrace ?? undefined,
    filePath: apiBug.filePath ?? undefined,
    lineNumber: apiBug.lineNumber ?? undefined,
  };
}

interface BugListResponse {
  items: ApiBug[];
  total: number;
  page: number;
  limit: number;
}

export interface FetchBugsParams {
  projectId: string;
  page?: number;
  limit?: number;
  severity?: SeverityLevel;
  status?: BugStatus;
  search?: string;
}

export async function fetchBugs(params: FetchBugsParams): Promise<{ bugs: Bug[]; total: number }> {
  const query = new URLSearchParams();
  query.set('projectId', params.projectId);
  query.set('page', String(params.page ?? 1));
  query.set('limit', String(params.limit ?? 50));
  if (params.severity) query.set('severity', params.severity);
  if (params.status) query.set('status', STATUS_TO_API[params.status]);
  if (params.search) query.set('search', params.search);

  const result = await apiRequest<BugListResponse>(`/bugs?${query.toString()}`);
  return { bugs: result.items.map(mapBugFromApi), total: result.total };
}

export interface CreateBugInput {
  projectId: string;
  title: string;
  description?: string;
  severity: SeverityLevel;
  language: string;
  component: string;
  filePath?: string;
  lineNumber?: number;
  stackTrace?: string;
  tags: string[];
}

export async function createBug(input: CreateBugInput): Promise<Bug> {
  const apiBug = await apiRequest<ApiBug>('/bugs', { method: 'POST', body: input });
  return mapBugFromApi(apiBug);
}

export interface UpdateBugInput {
  status?: BugStatus;
  severity?: SeverityLevel;
  tags?: string[];
}

export async function updateBug(bugId: string, input: UpdateBugInput): Promise<Bug> {
  const body: Record<string, unknown> = { ...input };
  if (input.status) body.status = STATUS_TO_API[input.status];

  const apiBug = await apiRequest<ApiBug>(`/bugs/${bugId}`, { method: 'PATCH', body });
  return mapBugFromApi(apiBug);
}
