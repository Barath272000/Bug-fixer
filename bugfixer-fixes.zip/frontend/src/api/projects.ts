import { apiRequest } from './client';

export interface ApiProject {
  id: string;
  name: string;
  sourceType: 'ZIP' | 'GITHUB' | 'PASTE';
  status: 'READY' | 'ANALYZING' | 'FAILED' | 'ARCHIVED';
  repositoryUrl?: string | null;
  defaultBranch?: string | null;
  createdAt: string;
  updatedAt: string;
}

interface ProjectListResponse {
  items: ApiProject[];
  total: number;
  page: number;
  limit: number;
}

export async function fetchProjects(page = 1, limit = 20): Promise<{ projects: ApiProject[]; total: number }> {
  const result = await apiRequest<ProjectListResponse>(`/projects?page=${page}&limit=${limit}`);
  return { projects: result.items, total: result.total };
}

export async function fetchProject(id: string): Promise<ApiProject> {
  return apiRequest<ApiProject>(`/projects/${id}`);
}

export interface CreateProjectInput {
  name: string;
  sourceType: 'ZIP' | 'GITHUB' | 'PASTE';
  repositoryUrl?: string;
  defaultBranch?: string;
}

export async function createProject(input: CreateProjectInput): Promise<ApiProject> {
  return apiRequest<ApiProject>('/projects', { method: 'POST', body: input });
}

export async function deleteProject(id: string): Promise<void> {
  await apiRequest<void>(`/projects/${id}`, { method: 'DELETE' });
}

/**
 * Convenience helper for the dev-token phase (no login/project-picker UI yet):
 * returns the user's first project, creating a default one if none exist.
 */
export async function getOrCreateDefaultProject(): Promise<ApiProject> {
  const { projects } = await fetchProjects(1, 1);
  if (projects.length > 0) return projects[0]!;
  return createProject({ name: 'My First Project', sourceType: 'PASTE' });
}
